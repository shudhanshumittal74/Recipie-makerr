import 'core-js/stable';
import 'regenerator-runtime/runtime';

import * as model from './model.js';
import searchView from './views/searchView.js';
import recipeView from './views/recipeView.js';
import resultView from './views/resultview.js';
import paginationView from './views/paginationView.js';
import bookmarkView from './views/bookmarkView.js';
import addRecipeView from './views/addRecipeView.js';
import { MODAL_CLOSE_SEC } from './config.js';


// if (module.hot){
//   module.hot.accept();
// }

const controlRecipe = async function () {
  try {
    const id = window.location.hash.slice(1);
    if (!id) return;

    recipeView.renderSpinner();

    // 0) Update results view to mark selected search result
    resultView.update(model.getSearchResultsPage());

    //  Update bookmark view
    bookmarkView.update(model.state.bookmark);

    // 1) Loading recipe
    await model.loadRecipe(id);

    // 2) Rendering recipe
    // const recipeView = new recipeView(model.state.recipe)
    //SAME AS
    recipeView.render(model.state.recipe);
  } catch (err) {
    recipeView.renderError();
    console.error(err);
  }

};
const controlSearchResult = async function () {
  try {
    resultView.renderSpinner();

    // 1) Get search query
    const query = searchView.getQuery();
    if (!query) return;

    // 2) Load search results
    await model.loadSearchResult(query);

    // 3) Render results
    // resultView.render(model.state.search.results);
    resultView.render(model.getSearchResultsPage());

    //4) Render initial pagination buttons
    paginationView.render(model.state.search);
  } catch (err) {
    console.log(err);
  }
};
const controlPagination = function (goToPage) {
  // Render New results
  resultView.render(model.getSearchResultsPage(goToPage));

  // Render New pagination buttons
  paginationView.render(model.state.search);
};
const controlServings = function (newServings) {
  // Update the recipe servings (in state)
  model.updateServings(newServings);

  // Update the recipe view
  // recipeView.render(model.state.recipe);
  recipeView.update(model.state.recipe);

};

const controlAddBookmark = function(){
  // 1) Add/remove bookmark
  if(!model.state.recipe.bookmarked) model.addBookmark(model.state.recipe);
  else model.deleteBookmark(model.state.recipe.id);

  // 2) Update recipe view
  recipeView.update(model.state.recipe)

  // 3) Render bookmark
  bookmarkView.render(model.state.bookmark)
}

const controlBookmarks = function(){
  bookmarkView.render(model.state.bookmark)
}

const controlAddRecipe = async function (newRecipe){
 try{

  // Show loading spinner
  addRecipeView.renderSpinner();

    // Uplaod the new recipe data
  await model.UplaodRecipe(newRecipe)
  console.log(model.state.recipe);

  // Render recipe
  recipeView.render(model.state.recipe);

  // Success message 
  addRecipeView.renderMessage();

  // Render bookmark view
  bookmarkView.render(model.state.bookmark)

  // Change id in the url
  window.history.pushState(null,'',`#${model.state.recipe.id}`);

  
  // Close form window
  setTimeout(function(){
  addRecipeView.toggleWindow();
  },MODAL_CLOSE_SEC * 1000)


 }catch(err){
  console.error('🃏🃏❤️',err);
  addRecipeView.renderError(err.message);
 }

}

const init = function () {
  bookmarkView.addHandlerRender(controlBookmarks);
  recipeView.addHandlerRender(controlRecipe);
  recipeView.addHandlerUpdateServings(controlServings);
  recipeView.addHandlerAddBookMark(controlAddBookmark);
  searchView.addHandlerSearch(controlSearchResult);
  paginationView.addHandlerClick(controlPagination);
  addRecipeView._addHandlerUpload(controlAddRecipe)
  console.log(
    'welcome'
  );
};
init();
